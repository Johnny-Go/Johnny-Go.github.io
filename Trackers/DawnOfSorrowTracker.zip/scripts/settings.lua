------------------------------------------------------------------
-- Configuration options for scripted systems in this pack
------------------------------------------------------------------
PREFERENCE_DISPLAY_ALL_LOCATIONS = true